<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
class SantoController extends Controller
{
    public function pari(){
    	return view('santo');
    }
    public function insert(Request $request){
    	
    	$data = array();
    		$data['name']=$request->name;
    		$data['location']=$request->location;
    		$data['mobile']=$request->mobile;
    		DB::table('pari')->insert($data);
    		return Redirect()->back();

    }
    public function all_data(){
    	$parinita = DB::table('pari')
                
                ->get();
                // echo "<pre>";
                // print_r($parinita);
                 return view('all_data', compact('parinita'));
    }
    public function Delete($id){
    		$delete = DB::table('pari')
    			->where('id', $id)
    			->delete();
    } 
}
