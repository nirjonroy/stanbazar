<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class nirjonController extends Controller
{
    public function mampy(){
    	return view('mampy');
    }
    public function info(Request $request){
    	$samsung = array();
    	$samsung['name']=$request->name;
    	$samsung['locatin']=$request->locatin;
    	$samsung['number']=$request->number;
    	DB::Table('mampy')->insert($samsung);
    	return Redirect()->back();
    }
}
