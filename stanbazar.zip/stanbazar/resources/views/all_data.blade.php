<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="1">
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>Location</th>
			<th>Mobile</th>
			<th>Action</th>
		</tr>
		@foreach($parinita as $pari)
		<tr>
			
				<td>{{$pari->id}}</td>
				<td>{{$pari->name}}</td>
				<td>{{$pari->location}}</td>
				<td>{{$pari->mobile}}</td>
				<td><a href="{{URL::to('delete-data/'.$pari->id)}}" id="delete" class="btn btn-sm btn-danger" >Delete</a></td>
		</tr>
		@endforeach
	</table>
</body>
</html>