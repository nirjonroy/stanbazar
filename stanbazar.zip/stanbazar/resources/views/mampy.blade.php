<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="{{url('tumr_bow_mampy')}}" method="post">
	@csrf
		<input type="text" name="name">
		<input type="text" name="locatin">
		<input type="text" name="number">
		<input type="submit" value="submite">

	</form>
</body>
</html>