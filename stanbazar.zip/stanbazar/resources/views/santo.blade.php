<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="{{url('insert-data')}}" method="post">
		@csrf
		<input type="text" name="name" placeholder="Type your name">
		<input type="text" name="location" placeholder="type your location">
		<input type="text" name="mobile" placeholder="enter your mobile number">
		<input type="submit" value="submit">
	</form>
	<br>
	<a href="{{url('all-data')}}">All data</a>
</body>
</html>