<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('santo');
// });
Route::get('/','SantoController@pari');
Route::post('insert-data', 'SantoController@insert');
Route::get('all-data','SantoController@all_data');

Route::get('/delete-data/{id}', 'SantoController@Delete');



Route::get ('nir', 'nirjonController@mampy');
Route::post ('tumr_bow_mampy', 'nirjonController@info');