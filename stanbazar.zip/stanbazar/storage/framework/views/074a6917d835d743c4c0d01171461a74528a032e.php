<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="<?php echo e(url('insert-data')); ?>" method="post">
		<?php echo csrf_field(); ?>
		<input type="text" name="name" placeholder="Type your name">
		<input type="text" name="location" placeholder="type your location">
		<input type="text" name="mobile" placeholder="enter your mobile number">
		<input type="submit" value="submit">
	</form>
	<br>
	<a href="<?php echo e(url('all-data')); ?>">All data</a>
</body>
</html><?php /**PATH D:\xampp\htdocs\stanbazar\resources\views/santo.blade.php ENDPATH**/ ?>