<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="<?php echo e(url('tumr_bow_mampy')); ?>" method="post">
	<?php echo csrf_field(); ?>
		<input type="text" name="name">
		<input type="text" name="locatin">
		<input type="text" name="number">
		<input type="submit" value="submite">

	</form>
</body>
</html><?php /**PATH D:\xampp\htdocs\stanbazar\resources\views/mampy.blade.php ENDPATH**/ ?>