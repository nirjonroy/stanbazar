<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="1">
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>Location</th>
			<th>Mobile</th>
			<th>Action</th>
		</tr>
		<?php $__currentLoopData = $parinita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			
				<td><?php echo e($pari->id); ?></td>
				<td><?php echo e($pari->name); ?></td>
				<td><?php echo e($pari->location); ?></td>
				<td><?php echo e($pari->mobile); ?></td>
				<td><a href="<?php echo e(URL::to('delete-data/'.$pari->id)); ?>" id="delete" class="btn btn-sm btn-danger" >Delete</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html><?php /**PATH D:\xampp\htdocs\stanbazar\resources\views/all_data.blade.php ENDPATH**/ ?>